# Do It Quant - React Native Project

[Project Link](https://github.com/feelcard/React_Native_Test)

<br>

### Install Packages
```cmd
$npm install
```

### Start Application
```cmd
expo start
```