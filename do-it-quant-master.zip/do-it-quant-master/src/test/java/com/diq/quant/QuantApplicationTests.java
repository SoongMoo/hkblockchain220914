package com.diq.quant;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuantApplicationTests {

	@Test
	void contextLoads() {
	}

}
