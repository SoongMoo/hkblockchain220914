package com.diq.quant.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyDetailRepository extends JpaRepository<CompanyDetail, Long>{

}
